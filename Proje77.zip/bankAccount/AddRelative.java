package bankAccount;

public class AddRelative {

    public String fullName;
    public String age;

    public AddRelative(String fullName, String age) {
        this.fullName = fullName;

        if (relativeAgeChecker(age)) this.age=age;
        else this.age="0";

    }
    public boolean relativeAgeChecker (String age) {
        Users kullanici=new Users("");

        if (kullanici.checkAge(age).equalsIgnoreCase("You can get a credit card"))
        {
            return true;
        }

return false;

    }
}
