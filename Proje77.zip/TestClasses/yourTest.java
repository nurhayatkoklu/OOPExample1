package TestClasses;

import bankAccount.Users;

public class yourTest {

    public static void main(String[] args) {
        Users u1 = new Users("Steven" , "Gerard",
                "10/02/2000", "married" ,
                1000 , 2000);

        System.out.println(u1.accountNumber);
        System.out.println(u1.accountNumber2);


    }

    /*
        Create a Test for method in the Users randomNumberCreader

        Check all possible options
     */


    /*
         Users içindeki randomNumberCreader methodu için Test oluştur

        Tüm olası seçenekleri kontrol edin
     */






    /*
          Users içindeki checkAge için Test oluştur

        Tüm olası seçenekleri kontrol edin

     */
}
